#include "Planet.h"

Planet::Planet()
:x(0), y(0), dep_x(0), dep_y(0) {
}

Planet::~Planet() {

}