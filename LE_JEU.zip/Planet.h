#ifndef PLANET_H
#define PLANET_H

class Planet
{
public:
	Planet();
	~Planet();
	int x, y;
	int dep_x, dep_y;
};

#endif